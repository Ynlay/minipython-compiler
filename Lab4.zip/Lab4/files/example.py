def x():
	y = 5
def x():
	k =10

