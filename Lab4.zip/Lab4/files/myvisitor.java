import minipython.analysis.*;
import minipython.node.*;
import java.util.*;

public class myvisitor extends DepthFirstAdapter 
{
	private Hashtable symtable;	

	myvisitor(Hashtable symtable) 
	{
		this.symtable = symtable;
	}

	public void inASfuncStatement(ASfuncStatement node) 
	{
		String fName = node.getId().toString();
		int line = ((TId) node.getId()).getLine();
		if (symtable.containsKey(fName))
		{
			System.out.println("Line " + line + ": " +" Function " + fName +" is already defined");
		}
		else
		{
			symtable.put(fName, node);
		}
	}

}
